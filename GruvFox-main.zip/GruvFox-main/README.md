# GruvFox
GruvFox is a remix of dpcdpc11's theme, featuring the gruvbox color palette.


  [![Discord](https://discord.com/api/guilds/763847972013342740/widget.png)](https://discord.gg/82eTY8nSFH)
  [![GitHub release](https://img.shields.io/github/release/FirefoxCSSThemers/GruvFox.svg?style=flat&logo=github)](https://github.com/FirefoxCSSThemers/GruvFox/releases)


Gruvbox is a very trending color scheme, with setups, wallpapers, themes and stuff all over the place. So, why not a firefox theme?

Here's the color scheme:
![image](https://camo.githubusercontent.com/410b3ab80570bcd5b470a08d84f93caa5b4962ccd994ebceeb3d1f78364c2120/687474703a2f2f692e696d6775722e636f6d2f776136363678672e706e67)

So, here is the theme: 

This edition is made by [Agnihotra Nath](https://github.com/alfarexguy2019)

Original theme by [dpcdpc11](https://deviantart.com/dpcdpc11)

Got the idea in [Winthemers](https://discord.gg/82eTY8nSFH)

## Screenshot:

- macOS:

![image](https://user-images.githubusercontent.com/78948152/130265614-a7559ea7-70fd-44f9-a790-34c5c0e31493.png)

- Windows:

![image](https://user-images.githubusercontent.com/84819317/131429846-2e9b70a4-c538-4607-971e-b87e85f71241.png)
